#ifndef MOVES_H
#define MOVES_H

#include <string>
#include <array>
#include <iostream>

using namespace std::string_literals;

class X {
public:
    X()
        : X("5") {
    }
    X(std::string num)
        : x_(num) {
    }
    X(const X& other) = default;
    X& operator=(const X& other) = default;
    X(X&& other) : x_(std::exchange(other.x_, ""s)){
    }
    X& operator=(X&& other) = default;

    std::string GetX() const {
        return x_;
    }

private:
    std::string x_;
};



class SomeClass {
public:
    SomeClass(const X& x) : x_(x){}
    SomeClass(X&& x) : x_(std::move(x)){}

    void do_some(const X& x){
        std::cout << "do some with Lvalue ref "  << x.GetX() << std::endl;
    }
    void do_some(X&& x) {
        std::cout << "do some with Rvalue ref "  << x.GetX()  << std::endl;
    }

    void do_other(const X& x) {
        std::cout << "do other with Lvalue ref "  << x.GetX()  << std::endl;
        do_some(x);
    }
    void do_other(X&& x){
        //std::cout << "do other with Rvalue ref "  << x.GetX()  << std::endl;
        do_some(x);
    }

private:
    X x_;
};

void move_example() {
    int obj = 2;
//    2 = obj;
    int& ref_obj = obj;
    int* ptr_obg = &obj;
//    int& ref_2 = 2;
//    int* ptr_2 = 2;
    int&& y = 2;


//    int&& z = obj + 1;



//    std::move(obj);
//    auto obj2 = std::move(obj);

//    std::cout << obj << "  " << obj2 << std::endl;

//    {
//        X x1("abcdeabcdeqwertyujkjhgfdsertyujkjhvcdfghjmnbgfdrtgh");
//        X x2("2");
//        X x3 = std::move(x1);
//        std::cout <<"|" << x1.GetX() << std::endl;
//        std::cout <<"|"<< x3.GetX() << std::endl;
//    }


//    {
//        std::array<int, 5> source = {5,4,3,2,1};
//        std::array<int, 5> target = std::move(source);
//        std::cout << source[0] << " " << target[0] << std::endl;

//        std::array<std::string, 5> source_str = {"50000000000000000000000",
//                                                 "40000000000000000000000",
//                                                 "30000000000000000000000",
//                                                 "20000000000000000000000",
//                                                 "10000000000000000000000"};
//        std::array<std::string, 5> target_str = std::move(source_str);
//        std::cout << source_str[0] << " // " << target_str[0] << std::endl;
//    }

    {
        SomeClass a(X("abcd"));

//        a.do_some(X("one"));
//        X x("other one");
//        a.do_some(std::move(x));

        a.do_other(X("two"));

//        X x("lvalue");
//        a.do_some(x);
//        X x2("lvalue2");
//        a.do_other(x2);

    }
}

#endif // MOVES_H
