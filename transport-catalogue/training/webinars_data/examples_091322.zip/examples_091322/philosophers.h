#pragma once

#include <cassert>
#include <condition_variable>
#include <mutex>
#include <thread>
#include <vector>
#include <iostream>

#include "pcout.h"

void philosophers_example_deadlock()
{
    using namespace std::chrono_literals;

    const size_t maxPhilosophers = 5;

    using Chopstick = std::mutex;

    std::vector<Chopstick> chopsticks(maxPhilosophers);

    std::vector<std::thread> philosophers;
    for (size_t i = 0; i < maxPhilosophers; ++i)
    {
        philosophers.emplace_back(
            [i, &chopsticks]()
            {
               size_t cnt = 0;
               size_t max_cnt = 4;
               while (++cnt < max_cnt)
               {
                   {
                       const auto left = i;
                       const auto right = (i + 1) % maxPhilosophers;


                       std::lock_guard<Chopstick> leftLock(chopsticks[left]);
                       pcout{} << "philosopher" << i << " get left chopstick" <<std::endl;

                       pcout{} << "philosopher" << i << " think " <<std::endl;
                       std::this_thread::sleep_for(2s);

                       std::lock_guard<Chopstick> rightLock(chopsticks[right]);

                       // eat
                       pcout{} << "philosopher" << i << " eat "<< cnt << " times" <<std::endl;
                       std::this_thread::sleep_for(1s);
                       pcout{} << "philosopher" << i << " eat ended"<< cnt << " times" <<std::endl;
                   }
                   pcout{} << "philosopher" << i << " think " <<std::endl;
                   std::this_thread::sleep_for(2s);
                   pcout{} << "philosopher" << i << " think ended" <<std::endl;
               }
            });
    }

    for (auto& t : philosophers)
    {
        t.join();
    }

}

void philosophers_example_livelock()
{
    using namespace std::chrono_literals;

    const size_t maxPhilosophers = 5;

    using Chopstick = std::timed_mutex;//!!!

    std::vector<Chopstick> chopsticks(maxPhilosophers);

    std::vector<std::thread> philosophers;
    for (size_t i = 0; i < maxPhilosophers; ++i)
    {
        philosophers.emplace_back(
            [i, &chopsticks]()
            {
               size_t cnt = 0;
               size_t max_cnt = 4;
               while (++cnt < max_cnt)
               {
                   {
                       const auto left = i;
                       const auto right = (i + 1) % maxPhilosophers;

                       while(true){
                           std::lock_guard<Chopstick> leftLock(chopsticks[left]);
                           pcout{} << "philosopher" << i << " think about getted left chopsticks" <<std::endl;
                           std::this_thread::sleep_for(2s);
                           if (chopsticks[right].try_lock_for(1s)){
                               pcout{} << "philosopher" << i << " get right chopsticks" <<std::endl;
                               break;
                           }
                           else
                               continue;
                       }

                       // eat
                       pcout{} << "philosopher" << i << " eat "<< cnt << " times" <<std::endl;
                       std::this_thread::sleep_for(1s);
                       pcout{} << "philosopher" << i << " eat ended"<< cnt << " times" <<std::endl;
                       chopsticks[right].unlock();
                   }
                   pcout{} << "philosopher" << i << " think " <<std::endl;
                   std::this_thread::sleep_for(2s);
                   pcout{} << "philosopher" << i << " think ended" <<std::endl;
               }
            });
    }

    for (auto& t : philosophers)
    {
        t.join();
    }

}

class Steward
{
public:
    explicit Steward(size_t maxPhilosophers)
        : maxPhilosophers_(maxPhilosophers)
        , busyChopsticks_(maxPhilosophers)
    {
    }

    using Chopsticks = std::pair<size_t, size_t>;

    Chopsticks getChopsticks(size_t philosopher)
    {
        assert(philosopher < maxPhilosophers_);
        const auto chopsticks = getChopstickNumbers(philosopher);

        std::unique_lock<std::mutex> lock(mutex_);

        while (busyChopsticks_[chopsticks.first] == true
            || busyChopsticks_[chopsticks.second] == true)
        {
            chopsticksAreBack_.wait(lock);
        }

        busyChopsticks_[chopsticks.first] = true;
        busyChopsticks_[chopsticks.second] = true;

        return chopsticks;
    }

    void returnChopsticks(Chopsticks chopsticks)
    {
        {
            std::lock_guard<std::mutex> lock(mutex_);

            busyChopsticks_[chopsticks.first] = false;
            busyChopsticks_[chopsticks.second] = false;
        }

        chopsticksAreBack_.notify_all();
    }

private:
    const size_t maxPhilosophers_;

    std::vector<bool> busyChopsticks_;

    std::mutex mutex_;
    std::condition_variable chopsticksAreBack_;

    Chopsticks getChopstickNumbers(size_t philosopher)
    {
        // | P0 | P1 | P2 |
        // 0    1    2    3
        return std::make_pair(philosopher, (philosopher + 1)%maxPhilosophers_);
    }
};


void philosophers_example2()
{
    using namespace std::chrono_literals;

    const size_t maxPhilosophers = 5;

    Steward steward(maxPhilosophers);

    std::vector<std::thread> philosophers;
    for (size_t i = 0; i < maxPhilosophers; ++i)
    {
        philosophers.emplace_back(
            [i, &steward]()
            {
            size_t cnt = 0;
            size_t max_cnt = 4;
            while (++cnt < max_cnt)
            {
                const auto chopsticks = steward.getChopsticks(i);
                // eat
                pcout{} << "philosopher" << i << " eat" <<std::endl;
                std::this_thread::sleep_for(1s);
                pcout{} << "philosopher" << i << " eat ended"<< cnt << " times" <<std::endl;

                steward.returnChopsticks(chopsticks);

                pcout{} << "philosopher" << i << " think " <<std::endl;
                std::this_thread::sleep_for(2s);
                pcout{} << "philosopher" << i << " think ended" <<std::endl;
            }
            });
    }

    for (auto& t : philosophers)
    {
        t.join();
    }

}
