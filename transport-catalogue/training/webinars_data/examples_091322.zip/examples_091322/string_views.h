#include <string>
#include <string_view>
#include <map>
#include <iostream>

int len_str(const std::string& str)
{
    return str.size();
}

int len_sv(std::string_view sv)
{
    return sv.size();
}

std::string_view remove_prefix(std::string_view sv){
    std::string aa;
    std::string_view a;
    a = sv.substr(2);
//    for ( auto c : sv)
//        if (c != 'a')
//            a.push_back(c);
    return a;
}

void string_view_example() {

     //1
    std::string a = "123456789012345678901234567890123456789012";
    std::string b = "1234567890123";
    std::string_view sv_a = a;
    std::string_view part_s = sv_a.substr(6, 10);
//    std::string c = sv_a;


//    std::cout << len_str(a) << " "
//              << len_str(b) << " "
//              << len_str(sv_a) << " "
//              << len_str(std::string(sv_a)) << std::endl;
//    std::cout << len_sv(a) << " "
//              << len_sv(b) << " "
//              << len_sv(sv_a) << std::endl;

//    std::cout << a << " " << b << " " << sv_a << std::endl;

//    a = "opa1111111111111111111111111111111111111111111";
//    std::cout << sv_a << std::endl;

    {
        std::string_view some_sv = "aabbccddaaee";
        auto parsed_sv = remove_prefix(some_sv);
        std::cout << parsed_sv << std::endl;
    }
}

void string_view_map_example() {
    using namespace std;

    map<string, int, less<>> sv_counter;

    string a ="aaaaa";
    string b ="bbbbb";
    string_view c = "ccccc";
    string_view a_sv = a;
    string_view b_sv = b;

    sv_counter[a] = 1;
    sv_counter[b] = 2;
//    sv_counter[c] = 3;
//    sv_counter.insert({c,3});
//    sv_counter[std::string(c)] = 2;
    sv_counter.find(a_sv);
    sv_counter.find(c);
}
