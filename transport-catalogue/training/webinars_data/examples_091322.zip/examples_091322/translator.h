#ifndef TRANSLATOR_H
#define TRANSLATOR_H

#include <string_view>
#include <set>
#include <map>
#include <cassert>
#include <iostream>

using namespace std;




class Translator {
public:
    void Add(string_view source, string_view target)
    {
        auto source_sv = string_view(*(_buffer.insert(std::string(source)).first));
        auto target_sv = string_view(*(_buffer.insert(std::string(target)).first));

        _forwardT[source_sv] = target_sv;
        _backwardT[target_sv] = source_sv;
    }
    string_view TranslateForward(string_view source) const
    {
        auto it = _forwardT.find(source);//O(logN)
        if (it != _forwardT.end())
            return it->second;
        else
            return "";
    }
    string_view TranslateBackward(string_view target) const
    {
        auto it = _backwardT.find(target);
        if (it != _backwardT.end())
            return it->second;
        else
            return "";
    }

private:
    std::map<string_view, string_view> _forwardT;
    std::map<string_view, string_view> _backwardT;

    std::set<string> _buffer;
};

void Test1() {
        Translator translator;

        auto okno = string("okno"s);
        auto window = string("window"s);
        auto stol = string("stol"s);
        auto table = string("table"s);

        translator.Add(okno, window);
        translator.Add(stol, table);

        assert(translator.TranslateForward(okno) == window);
        assert(translator.TranslateForward(table) == ""s);
    }

    void Test2() {
        Translator translator;

        auto okno = string("okno"s);
        auto window = string("window"s);
        auto stol = string("stol"s);
        auto table = string("table"s);

        translator.Add(okno, window);
        translator.Add(stol, table);

        assert(translator.TranslateBackward(table) == stol);
        assert(translator.TranslateBackward(stol) == ""s);
    }

    void Test3() {
        Translator translator;
        translator.Add(string("okno"s), string("window"s));
        translator.Add(string("stol"s), string("table"s));

        assert(translator.TranslateForward("okno"s) == "window"s);
        assert(translator.TranslateBackward("table"s) == "stol"s);
        assert(translator.TranslateForward("table"s) == ""s);
    }

void TranslatorTests() {
    Test1();
    Test2();
    Test3();
    std::cout << "tests passed" << std::endl;
}

#endif // TRANSLATOR_H
