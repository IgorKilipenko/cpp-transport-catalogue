#include <thread>
#include <iostream>
#include <vector>
#include <execution>
#include <functional>
#include <numeric>
#include <set>
#include <cassert>

#include "log_duration.h"

void do_something()
{
    using namespace std::chrono_literals;

    std::this_thread::sleep_for(3s);
    std::cout << "i just sleep" << std::endl;
}

struct Dog {
    Dog() = default;
    Dog(const std::string& s) : name_(s){}
    Dog& operator=(const Dog& other) = default;

    void walk() {
        isHappy_ = true;
        std::cout << name_ << " walked" << std::endl;
    }
    bool isHappy() const {return isHappy_;}

    std::string name_;
    bool isHappy_ = false;
};

void go_to_walk_with_dogs(std::vector<Dog>& dogs)
{
    using namespace std::chrono_literals;

    std::this_thread::sleep_for(3s);
    std::cout << "i just walk with dogs in " << std::this_thread::get_id() << std::endl;
    for (auto& d : dogs)
        d.walk();
}

void threads_example() {
    using namespace std::chrono_literals;

//    std::thread t(do_something);

    std::vector<Dog> dogs(10,{"CoolDogName"});
    std::thread t(go_to_walk_with_dogs, std::ref(dogs));

    std::cout << "DO something other " << std::this_thread::get_id() << std::endl;

//    t.join();

//    t.detach();
//    if (t.joinable())
//        t.join();
//    std::cout << "do another workin " << std::this_thread::get_id() << std::endl;
//    std::this_thread::sleep_for(5s);
//    std::cout << "another work donein " << std::this_thread::get_id() << std::endl;
    for (auto& d : dogs)
    {
        std::cout << d.name_ << " happiness " << d.isHappy() << std::endl;
    }
//    std::cout << "go to home" << std::endl;

//    t.join();

}

void par_vector_vs_set() {
    using std::string_literals::operator""s;

    std::vector<int> v(10'000'000);
    std::iota(v.begin(), v.end(),0);
    std::set<int> s(v.begin(), v.end());

    {
        LOG_DURATION("vector seq"s);
        std::reduce(std::execution::seq, v.begin(), v.end(), 0, [](int a, int b)
        {
            return a + b;
        });
    }
    {
        LOG_DURATION("vector par"s);
        std::reduce(std::execution::par, v.begin(), v.end(), 0, [](int a, int b)
        {
            return a + b;
        });
    }
    {
        LOG_DURATION("set seq"s);
        std::reduce(std::execution::seq, s.begin(), s.end(), 0, [](int a, int b)
        {
            return a + b;
        });
    }
    {
        LOG_DURATION("set par"s);
        std::reduce(std::execution::par, s.begin(), s.end(), 0, [](int a, int b)
        {
            return a + b;
        });
    }
}

void vector_resize_vs_reserve() {
    using std::string_literals::operator""s;
    std::vector<int> v(10'000'000);
    std::iota(v.begin(), v.end(),0);
    {
        LOG_DURATION("vector resize  seq"s);
        std::vector<int> a(10'000'000);
        std::copy_if(std::execution::seq, v.begin(), v.end(), a.begin(),[](int n){return n %1 == 0;});
    }
    {
        LOG_DURATION("vector resize  par"s);
        std::vector<int> a(10'000'000);
        std::copy_if(std::execution::par, v.begin(), v.end(), a.begin(),[](int n){return n %1 == 0;});
    }
    {
        LOG_DURATION("vector resize  nor"s);
        std::vector<int> a(10'000'000);
        std::copy_if(v.begin(), v.end(), a.begin(),[](int n){return n %1 == 0;});
    }
    {
        LOG_DURATION("vector reserve seq"s);
        std::vector<int> b;
        b.reserve(10'000'000);
        std::copy_if(std::execution::seq,v.begin(), v.end(), std::back_inserter(b),[](int n){return n %1 == 0;});
        assert(b.size() == v.size());
    }
    {
        LOG_DURATION("vector reserve par"s);
        std::vector<int> b;
        b.reserve(10'000'000);
        std::copy_if(std::execution::par,v.begin(), v.end(), std::back_inserter(b),[](int n){return n %1 == 0;});
        assert(b.size() == v.size());
    }
    {
        LOG_DURATION("vector reserve nor"s);
        std::vector<int> b;
        b.reserve(10'000'000);
        std::copy_if(v.begin(), v.end(), std::back_inserter(b),[](int n){return n %1 == 0;});
        assert(b.size() == v.size());
    }
}
