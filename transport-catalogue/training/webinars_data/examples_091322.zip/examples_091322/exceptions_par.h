#ifndef EXCEPTIONS_PAR_H
#define EXCEPTIONS_PAR_H

#include <vector>
#include <numeric>
#include <atomic>
#include <execution>
#include <iostream>

void exeptions_in_par() {

    std::vector<int> v(100);
    std::iota(v.begin(), v.end(), 0);
    std::atomic_int a = 0;
    try {
        std::for_each(v.begin(), v.end(),[&a,&v](int i)
        {
            if (i == 0)
                throw std::invalid_argument("ZERO!!!");
            a += v.at(i);
        });
    }
    catch (const std::invalid_argument& e)
    {
        std::cout << "invalid_argument" << e.what() << std::endl;
    }
    catch (const std::exception& e)
    {
        std::cout << "exception " << e.what() << std::endl;
    }
}

#endif // EXCEPTIONS_PAR_H
