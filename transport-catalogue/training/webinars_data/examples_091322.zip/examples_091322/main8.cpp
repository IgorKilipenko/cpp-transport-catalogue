#include <vector>
#include <iostream>
#include <string>
#include <map>
#include <set>
#include <list>

#include "log_duration.h"

#include "moves.h"
#include "string_views.h"
#include "translator.h"

#include "threads.h"
#include "philosophers.h"
#include "exceptions_par.h"
#include "accumulate.h"
#include "pcout.h"
using namespace std;


int main() {

//    move_example();

//    TranslatorTests();
//    string_view_example();
//    string_view_map_example();


//    threads_example();
//    parallel_accumulate()
//    par_vector_vs_set();
//    vector_resize_vs_reserve();
//    exeptions_in_par();



//    pcout_example();
//    philosophers_example_deadlock();
//    philosophers_example_livelock();
//    philosophers_example2();

}
