#ifndef PCOUT_H
#define PCOUT_H

#include <iostream>
#include <mutex>
#include <sstream>
#include <vector>
#include <thread>

struct pcout : public std::stringstream {
    static inline std::mutex cout_mutex;
    ~pcout() {
        std::lock_guard<std::mutex> l {cout_mutex};
        std::cout << rdbuf();
        std::cout.flush();
    }
};


static void print_cout(int id) {
   std:: cout << "cout hello from " << id << '\n';
}
static void print_pcout(int id) {
    pcout{} << "pcout hello from " << id << '\n';
}

void pcout_example()
{
    std::vector<std::thread> v;
    for (size_t i {0}; i < 10; ++i) {
        v.emplace_back(print_cout, i);
    }
    for (auto &t : v)
        t.join();


    std::cout << "=====================\n";
    v.clear();
    for (size_t i {0}; i < 10; ++i) {
        v.emplace_back(print_pcout, i);
    }
    for (auto &t : v)
        t.join();
}

#endif // PCOUT_H
